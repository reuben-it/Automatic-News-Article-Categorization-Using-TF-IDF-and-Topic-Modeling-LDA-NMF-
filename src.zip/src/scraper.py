
import os
import feedparser
import pandas as pd


def scrape_articles(url, num_articles=10):
    """Fetch articles from an RSS/Atom feed."""
    articles_data = []
    feed = feedparser.parse(url)

    if feed.bozo:
        # feed.bozo_exception holds parsing errors
        print(f"Feed parsing error: {feed.bozo_exception}")
        return articles_data

    if not feed.entries:
        print("No entries found in the feed. Verify the feed URL.")
        return articles_data

    for entry in feed.entries[:num_articles]:
        title = entry.get("title", "No Title")
        summary = entry.get("summary", "")

        # Some feeds include full content in the 'content' field
        content_field = entry.get("content", [])
        if content_field:
            content = content_field[0].get("value", "")
        else:
            content = summary

        articles_data.append({"title": title, "content": content})

    return articles_data

def save_to_csv(data, filename='news_articles.csv', directory='../data'):
    if not os.path.exists(directory):
        os.makedirs(directory)
    filepath = os.path.join(directory, filename)
    df = pd.DataFrame(data)
    df.to_csv(filepath, index=False)
    print(f"Scraped {len(data)} articles and saved to {filepath}")

if __name__ == "__main__":
    # Example usage: replace with any publicly available RSS feed.
    target_url = "https://rss.cnn.com/rss/edition.rss"
    print(f"Scraping articles from feed: {target_url}")
    scraped_data = scrape_articles(target_url, num_articles=5)
    if scraped_data:
        save_to_csv(scraped_data)
    else:
        print("No articles scraped.")
