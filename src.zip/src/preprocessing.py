
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd

# Download necessary NLTK data (only run once)
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def preprocess_text(text):
    if not isinstance(text, str):
        return ""
    # Remove special characters and numbers
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Convert to lowercase
    text = text.lower()
    # Tokenize and remove stopwords, then lemmatize
    tokens = text.split()
    cleaned_tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    return ' '.join(cleaned_tokens)

def load_and_preprocess_data(filepath='../data/news_articles.csv'):
    try:
        df = pd.read_csv(filepath)
        df['processed_content'] = df['content'].apply(preprocess_text)
        return df
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}. Please ensure data is scraped and saved.")
        return pd.DataFrame()

def extract_features_tfidf(data_series):
    vectorizer = TfidfVectorizer(max_features=1000)  # Limiting features for demonstration
    tfidf_matrix = vectorizer.fit_transform(data_series)
    return tfidf_matrix, vectorizer

if __name__ == "__main__":
    # This part will only run if you execute preprocessing.py directly
    # It assumes you have a news_articles.csv in the ../data directory
    print("Loading and preprocessing data...")
    processed_df = load_and_preprocess_data()

    if not processed_df.empty:
        print("Data preprocessed successfully. First 5 rows of processed content:")
        print(processed_df[['title', 'processed_content']].head())

        print("Extracting TF-IDF features...")
        tfidf_matrix, tfidf_vectorizer = extract_features_tfidf(processed_df['processed_content'])
        print(f"TF-IDF matrix shape: {tfidf_matrix.shape}")
        print("TF-IDF feature extraction complete.")
    else:
        print("No data to preprocess or extract features from.")

