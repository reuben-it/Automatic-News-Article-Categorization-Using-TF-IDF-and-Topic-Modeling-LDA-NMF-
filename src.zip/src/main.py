
import argparse
import os
import pandas as pd

from scraper import scrape_articles, save_to_csv
from preprocessing import load_and_preprocess_data, extract_features_tfidf, preprocess_text
from models import apply_lda, apply_nmf, display_topics

def main():
    parser = argparse.ArgumentParser(description="Automatic News Article Categorization via Topic Modeling.")
    parser.add_argument("--scrape", action="store_true", help="Scrape news articles.")
    parser.add_argument("--url", type=str, default="https://example.com/news",
                        help="URL to scrape news articles from. (Defaults to a placeholder, please change)")
    parser.add_argument("--num_articles", type=int, default=10, help="Number of articles to scrape.")
    parser.add_argument("--process_and_model", action="store_true", help="Process data and apply topic models.")
    parser.add_argument("--n_topics", type=int, default=5, help="Number of topics for LDA and NMF.")
    parser.add_argument("--n_top_words", type=int, default=10, help="Number of top words to display per topic.")
    parser.add_argument("--data_file", type=str, default="news_articles.csv",
                        help="Filename of the scraped data CSV.")

    args = parser.parse_args()

    data_filepath = os.path.join('data', args.data_file)

    if args.scrape:
        print(f"--- Starting Data Scraping from {args.url} ---")
        if args.url == "https://example.com/news":
            print("WARNING: Using a placeholder URL. Please change the --url argument to a real news website URL.")
        scraped_data = scrape_articles(args.url, args.num_articles)
        if scraped_data:
            save_to_csv(scraped_data, filename=args.data_file, directory='./data')
        else:
            print("Scraping completed, but no articles were retrieved. Check URL and scraper logic.")
        print("--- Data Scraping Finished ---\n")

    if args.process_and_model:
        print("--- Starting Data Preprocessing and Topic Modeling ---")
        processed_df = load_and_preprocess_data(filepath=data_filepath)

        if not processed_df.empty:
            tfidf_matrix, tfidf_vectorizer = extract_features_tfidf(processed_df['processed_content'])
            feature_names = tfidf_vectorizer.get_feature_names_out()

            print(f"Applying LDA with {args.n_topics} components...")
            lda_model, lda_output = apply_lda(tfidf_matrix, args.n_topics)
            print("Topics in LDA model:")
            display_topics(lda_model, feature_names, args.n_top_words)
            processed_df['lda_topic'] = lda_output.argmax(axis=1)

            print(f"Applying NMF with {args.n_topics} components...")
            nmf_model, nmf_output = apply_nmf(tfidf_matrix, args.n_topics)
            print("Topics in NMF model:")
            display_topics(nmf_model, feature_names, args.n_top_words)
            processed_df['nmf_topic'] = nmf_output.argmax(axis=1)

            print("First few articles with assigned LDA and NMF topics:")
            print(processed_df[['title', 'lda_topic', 'nmf_topic']].head())

            # You can save the processed_df with topics if needed
            # processed_df.to_csv(os.path.join('data', 'categorized_articles.csv'), index=False)
        else:
            print("No data to process and model. Please ensure scraping was successful.")
        print("--- Preprocessing and Topic Modeling Finished ---\n")

if __name__ == "__main__":
    main()

