
from sklearn.decomposition import LatentDirichletAllocation, NMF

def apply_lda(tfidf_matrix, n_components=5):
    lda_model = LatentDirichletAllocation(n_components=n_components, random_state=42)
    lda_output = lda_model.fit_transform(tfidf_matrix)
    return lda_model, lda_output

def apply_nmf(tfidf_matrix, n_components=5):
    nmf_model = NMF(n_components=n_components, random_state=42, init='nndsvda', tol=1e-4, max_iter=200)
    nmf_output = nmf_model.fit_transform(tfidf_matrix)
    return nmf_model, nmf_output

def display_topics(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components__):
        print(f"Topic #{topic_idx + 1}:")
        print(" ".join([feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]]))
    print()

if __name__ == "__main__":
    # This part will only run if you execute models.py directly
    # It assumes you have run preprocessing.py and have a tfidf_matrix
    import pandas as pd
    import numpy as np
    from preprocessing import load_and_preprocess_data, extract_features_tfidf

    print("Loading and preprocessing data for topic modeling...")
    processed_df = load_and_preprocess_data()

    if not processed_df.empty:
        tfidf_matrix, tfidf_vectorizer = extract_features_tfidf(processed_df['processed_content'])
        feature_names = tfidf_vectorizer.get_feature_names_out()

        n_components = 5 # Number of topics
        n_top_words = 10  # Number of words to display per topic

        print(f"Applying LDA with {n_components} components...")
        lda_model, lda_output = apply_lda(tfidf_matrix, n_components)
        print("Topics in LDA model:")
        display_topics(lda_model, feature_names, n_top_words)

        print(f"Applying NMF with {n_components} components...")
        nmf_model, nmf_output = apply_nmf(tfidf_matrix, n_components)
        print("Topics in NMF model:")
        display_topics(nmf_model, feature_names, n_top_words)

        # Assign topics to articles
        processed_df['lda_topic'] = lda_output.argmax(axis=1)
        processed_df['nmf_topic'] = nmf_output.argmax(axis=1)

        print("First 5 articles with assigned LDA and NMF topics:")
        print(processed_df[['title', 'lda_topic', 'nmf_topic']].head())
    else:
        print("No data to apply topic models on. Please ensure scraping and preprocessing are successful.")

