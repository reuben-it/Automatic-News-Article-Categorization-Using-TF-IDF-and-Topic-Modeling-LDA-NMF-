import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd

# Download necessary NLTK data (only run once)
try:
    nltk.data.find("corpora/stopwords")
except LookupError:
    nltk.download("stopwords")
try:
    nltk.data.find("corpora/wordnet")
except LookupError:
    nltk.download("wordnet")

stop_words = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()


def preprocess_text(text):
    if not isinstance(text, str):
        return ""
    # Remove special characters and numbers
    text = re.sub(r"[^a-zA-Z\s]", "", text)
    # Convert to lowercase
    text = text.lower()
    # Tokenize and remove stopwords, then lemmatize
    tokens = text.split()
    cleaned_tokens = [
        lemmatizer.lemmatize(word) for word in tokens if word not in stop_words
    ]
    return " ".join(cleaned_tokens)


def _sample_offline_articles():
    """Fallback small offline dataset so the app works without any external data."""
    data = [
        {
            "title": "Government passes new climate change bill",
            "content": "The national government passed a new climate change bill focusing on renewable energy, emissions cuts, and green jobs.",
        },
        {
            "title": "Tech company releases next-generation smartphone",
            "content": "A leading tech company unveiled its latest smartphone featuring an advanced camera, faster processor, and improved battery life.",
        },
        {
            "title": "Local team wins international football championship",
            "content": "Fans celebrated as the local football team won the international championship after a dramatic penalty shootout.",
        },
        {
            "title": "Scientists discover new exoplanet in habitable zone",
            "content": "Astronomers announced the discovery of an Earth-sized exoplanet located in the habitable zone of a nearby star.",
        },
        {
            "title": "Stock markets fall amid global economic uncertainty",
            "content": "Global stock markets declined as investors reacted to concerns over inflation, interest rates, and slowing economic growth.",
        },
        {
            "title": "New study links regular exercise to improved mental health",
            "content": "Researchers found that people who exercise regularly report lower levels of anxiety and depression and better overall well-being.",
        },
        {
            "title": "City introduces major public transport expansion",
            "content": "The city announced a major expansion of its public transport network including new metro lines and electric buses.",
        },
        {
            "title": "Breakthrough in cancer treatment shows promising results",
            "content": "A clinical trial of a new cancer therapy showed promising results in reducing tumor size with fewer side effects.",
        },
    ]
    return pd.DataFrame(data)


def load_and_preprocess_data(filepath="data/news_articles.csv"):
    """
    Load and preprocess data.
    Currently forced to use built-in sample articles so the app
    always runs offline and is independent of any external data.
    """
    print("Using built-in sample articles (offline mode).")
    df = _sample_offline_articles()
    df["processed_content"] = df["content"].apply(preprocess_text)
    return df


def extract_features_tfidf(data_series):
    vectorizer = TfidfVectorizer(max_features=1000)  # Limiting features for demonstration
    tfidf_matrix = vectorizer.fit_transform(data_series)
    return tfidf_matrix, vectorizer


if __name__ == "__main__":
    print("Loading and preprocessing data...")
    processed_df = load_and_preprocess_data()

    if not processed_df.empty:
        print("Data preprocessed successfully. First 5 rows of processed content:")
        print(processed_df[["title", "processed_content"]].head())

        print("Extracting TF-IDF features...")
        tfidf_matrix, tfidf_vectorizer = extract_features_tfidf(
            processed_df["processed_content"]
        )
        print(f"TF-IDF matrix shape: {tfidf_matrix.shape}")
        print("TF-IDF feature extraction complete.")
    else:
        print("No data to preprocess or extract features from.")


