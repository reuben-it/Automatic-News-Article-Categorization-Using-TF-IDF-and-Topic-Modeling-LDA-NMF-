import argparse
import os
import sys
from pathlib import Path

# Ensure local src directory is on sys.path when running as a script
SRC_DIR = Path(__file__).resolve().parent
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from scraper import scrape_articles, save_to_csv
from preprocessing import load_and_preprocess_data, extract_features_tfidf
from models import apply_lda, apply_nmf

CATEGORY_KEYWORDS = {
    "Politics & Policy": {
        "government",
        "president",
        "election",
        "policy",
        "bill",
        "law",
        "parliament",
        "minister",
    },
    "Business & Economy": {
        "market",
        "economy",
        "inflation",
        "stock",
        "growth",
        "company",
        "trade",
        "investment",
        "finance",
    },
    "Technology": {
        "technology",
        "tech",
        "software",
        "hardware",
        "ai",
        "robot",
        "internet",
        "smartphone",
        "device",
        "digital",
    },
    "Science & Space": {
        "science",
        "scientist",
        "space",
        "planet",
        "research",
        "study",
        "discovery",
        "astronomer",
        "lab",
    },
    "Health": {
        "health",
        "medical",
        "hospital",
        "disease",
        "cancer",
        "virus",
        "wellbeing",
        "vaccine",
        "doctor",
    },
    "Sports": {
        "sport",
        "football",
        "soccer",
        "basketball",
        "cricket",
        "match",
        "tournament",
        "coach",
        "team",
        "player",
    },
    "Environment": {
        "climate",
        "environment",
        "emission",
        "wildfire",
        "pollution",
        "renewable",
        "carbon",
        "weather",
    },
}


def extract_top_words(model, feature_names, n_top_words):
    topics = []
    for topic in model.components_:
        top_indices = topic.argsort()[: -n_top_words - 1 : -1]
        topics.append([feature_names[i] for i in top_indices])
    return topics


def infer_category_from_words(top_words):
    top_word_set = set(top_words)
    best_label = None
    best_overlap = 0

    for label, keywords in CATEGORY_KEYWORDS.items():
        overlap = len(top_word_set & keywords)
        if overlap > best_overlap:
            best_overlap = overlap
            best_label = label

    if best_label:
        return best_label
    # fallback – just show a short summary made from the most dominant words
    return " / ".join(top_words[:3]).title()


def main():
    parser = argparse.ArgumentParser(
        description="Automatic News Article Categorization via Topic Modeling."
    )
    parser.add_argument(
        "--scrape",
        action="store_true",
        help="(Optional) Scrape news articles from an RSS feed. Not required in offline mode.",
    )
    parser.add_argument(
        "--url",
        type=str,
        default="https://feeds.npr.org/1004/rss.xml",
        help="RSS/Atom feed URL to scrape. Defaults to NPR world news feed.",
    )
    parser.add_argument(
        "--num_articles", type=int, default=10, help="Number of feed entries to pull."
    )
    parser.add_argument(
        "--process_and_model",
        action="store_true",
        help="Run preprocessing and topic models.",
    )
    parser.add_argument(
        "--n_topics", type=int, default=5, help="Number of topics for LDA and NMF."
    )
    parser.add_argument(
        "--n_top_words",
        type=int,
        default=10,
        help="Top words to show per topic for each model.",
    )
    parser.add_argument(
        "--data_file",
        type=str,
        default="news_articles.csv",
        help="CSV filename stored in the data/ directory.",
    )

    args = parser.parse_args()
    data_filepath = os.path.join("data", args.data_file)

    if args.scrape:
        print(f"--- Scraping feed: {args.url} ---")
        scraped_data = scrape_articles(args.url, args.num_articles)
        if scraped_data:
            save_to_csv(scraped_data, filename=args.data_file, directory="data")
        else:
            print("No entries retrieved. Check the feed URL or network connectivity.")
        print("--- Scraping complete ---\n")

    if args.process_and_model:
        print("--- Loading data for preprocessing ---")
        processed_df = load_and_preprocess_data(filepath=data_filepath)
        if processed_df.empty:
            print("No data available. Scrape first or verify the data file path.")
            return

        tfidf_matrix, vectorizer = extract_features_tfidf(
            processed_df["processed_content"]
        )
        feature_names = vectorizer.get_feature_names_out()

        print(f"Applying LDA with {args.n_topics} topics...")
        lda_model, lda_output = apply_lda(tfidf_matrix, args.n_topics)
        lda_topic_words = extract_top_words(
            lda_model, feature_names, args.n_top_words
        )
        lda_topic_labels = [
            infer_category_from_words(words) for words in lda_topic_words
        ]
        for idx, (words, label) in enumerate(
            zip(lda_topic_words, lda_topic_labels), start=1
        ):
            print(f"Topic #{idx} - {label}: {' '.join(words)}")
        processed_df["lda_topic"] = lda_output.argmax(axis=1)
        processed_df["lda_topic_label"] = processed_df["lda_topic"].apply(
            lambda idx: lda_topic_labels[idx]
        )

        print(f"\nApplying NMF with {args.n_topics} topics...")
        nmf_model, nmf_output = apply_nmf(tfidf_matrix, args.n_topics)
        nmf_topic_words = extract_top_words(
            nmf_model, feature_names, args.n_top_words
        )
        nmf_topic_labels = [
            infer_category_from_words(words) for words in nmf_topic_words
        ]
        for idx, (words, label) in enumerate(
            zip(nmf_topic_words, nmf_topic_labels), start=1
        ):
            print(f"Topic #{idx} - {label}: {' '.join(words)}")
        processed_df["nmf_topic"] = nmf_output.argmax(axis=1)
        processed_df["nmf_topic_label"] = processed_df["nmf_topic"].apply(
            lambda idx: nmf_topic_labels[idx]
        )

        print("First few labeled articles:")
        print(
            processed_df[
                [
                    "title",
                    "lda_topic",
                    "lda_topic_label",
                    "nmf_topic",
                    "nmf_topic_label",
                ]
            ].head()
        )


if __name__ == "__main__":
    main()


{
  "cells": [],
  "metadata": {
    "language_info": {
      "name": "python"
    }
  },
  "nbformat": 4,
  "nbformat_minor": 2
}