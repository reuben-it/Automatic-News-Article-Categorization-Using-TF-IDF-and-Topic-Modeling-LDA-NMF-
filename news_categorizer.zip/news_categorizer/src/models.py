from sklearn.decomposition import LatentDirichletAllocation, NMF


def apply_lda(tfidf_matrix, n_components=5):
    lda_model = LatentDirichletAllocation(n_components=n_components, random_state=42)
    lda_output = lda_model.fit_transform(tfidf_matrix)
    return lda_model, lda_output


def apply_nmf(tfidf_matrix, n_components=5):
    nmf_model = NMF(
        n_components=n_components,
        random_state=42,
        init="nndsvda",
        tol=1e-4,
        max_iter=200,
    )
    nmf_output = nmf_model.fit_transform(tfidf_matrix)
    return nmf_model, nmf_output


def display_topics(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        print(f"Topic #{topic_idx + 1}:")
        print(
            " ".join(
                [feature_names[i] for i in topic.argsort()[: -n_top_words - 1 : -1]]
            )
        )
    print()


if __name__ == "__main__":
    # Simple smoke test would go here if needed
    print("models.py is intended to be imported, not run directly.")


