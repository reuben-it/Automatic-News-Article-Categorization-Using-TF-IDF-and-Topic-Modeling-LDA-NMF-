
import os
import feedparser
import pandas as pd


def scrape_articles(url, num_articles=10):
    """Fetch entries from an RSS/Atom feed using feedparser."""
    articles_data = []
    feed = feedparser.parse(url)

    if feed.bozo:
        print(f"Feed parsing error: {feed.bozo_exception}")
        return articles_data

    entries = feed.entries[:num_articles]
    if not entries:
        print("No entries found in the feed. Verify the feed URL.")
        return articles_data

    for entry in entries:
        title = entry.get("title", "No Title")
        summary = entry.get("summary", "")
        content_items = entry.get("content", [])
        if content_items:
            content = content_items[0].get("value", "")
        else:
            content = summary

        articles_data.append({"title": title, "content": content})

    return articles_data


def save_to_csv(data, filename="news_articles.csv", directory="data"):
    if not os.path.exists(directory):
        os.makedirs(directory)
    filepath = os.path.join(directory, filename)
    df = pd.DataFrame(data)
    df.to_csv(filepath, index=False)
    print(f"Scraped {len(data)} articles and saved to {filepath}")


if __name__ == "__main__":
    example_feed = "https://feeds.reuters.com/reuters/worldNews"
    print(f"Scraping articles from feed: {example_feed}")
    scraped = scrape_articles(example_feed, num_articles=5)
    if scraped:
        save_to_csv(scraped)
    else:
        print("No articles scraped.")
